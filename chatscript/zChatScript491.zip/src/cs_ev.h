﻿#ifndef __CS_EV_H__
#define __CS_EV_H__

#ifndef DISCARDSERVER
#ifdef EVSERVER
#include "evserver/ev.h"
#endif
#endif

#endif /* __CS_EV_H__ */
