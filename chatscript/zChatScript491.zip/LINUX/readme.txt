To autostart server using cron, use   crontab  jobs.cron  (if you are in the LINUX directory)

in apache the index page (script to run chatbot) can be in /var/www/html/index.php

sudo -s to access the var file

to install g++
sudo apt-get install g++
sudo apt-get install gdb
sudo apt-get install make


if crontab doesnt seem to work, consider: 
/etc/init.d/crond restart